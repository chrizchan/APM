The following are recommended Pluralsight courses related to this course:

* For beginners learning Angular
  - [AngularJS: Get Started] (http://www.pluralsight.com/courses/angularjs-get-started)
  - [Shaping Up with AngularJS] (http://angular.codeschool.com/)

* After learning the basics of Angular
  - [AngularJS Line of Business Applications] (http://www.pluralsight.com/courses/angularjs-line-of-business-applications)
  - [AngularJS Patterns: Clean Code](http://www.pluralsight.com/courses/angularjs-patterns-clean-code)

* REST
  - [REST Fundamentals] (http://www.pluralsight.com/courses/rest-fundamentals)

* OData
  - [Introduction to OData] (http://www.pluralsight.com/courses/odata-introduction)
  - [Building ASP.NET Web API OData Services] (http://www.pluralsight.com/courses/aspnetwebapi-odata)
  
* Security
  - [AngularJS Security Fundamentals] (http://www.pluralsight.com/courses/angularjs-security-fundamentals)
  - [Building and Securing a RESTful API for Multiple Clients in ASP.NET] (http://www.pluralsight.com/courses/building-securing-restful-api-aspdotnet)
  - [Web API v2 Security] (http://www.pluralsight.com/courses/webapi-v2-security)

* For LINQ
  - [Practical LINQ] (http://www.pluralsight.com/courses/practical-linq)

* For unit testing
  - [Defensive Coding in C#] (http://www.pluralsight.com/courses/defensive-coding-csharp)
