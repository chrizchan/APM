For more information on Cookies vs Tokens:

* "Cookies vs Tokens. Getting auth right with Angular.JS.

  https://auth0.com/blog/2014/01/07/angularjs-authentication-with-cookies-vs-token/

* "10 Things You Should Know About Tokens"

  https://auth0.com/blog/2014/01/27/ten-things-you-should-know-about-tokens-and-cookies/

* "AngularJS Security Fundamentals" Pluralsight course by Troy Hunt.

  http://www.pluralsight.com/training/player?author=troy-hunt&name=angularjs-security-fundamentals-m03-server-security-controls&mode=live&clip=3&course=angularjs-security-fundamentals
