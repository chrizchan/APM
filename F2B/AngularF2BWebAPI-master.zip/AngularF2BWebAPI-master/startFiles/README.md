This folder contains files you can use as a starting point when building along with the "Angular Front to Back with Web API" course sample application.
