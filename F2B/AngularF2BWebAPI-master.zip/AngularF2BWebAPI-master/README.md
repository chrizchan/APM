# AngularF2BWebAPI
Files for the "Angular Front to Back With Web API" Pluralsight course by Deborah Kurata.

STATUS: Course is in development and should be posted to the Pluralsight library in April 2015.
